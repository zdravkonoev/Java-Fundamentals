package com.company;

/**
 * Created by User on 3/19/2016.
 */
public class AssignVariables {
}
