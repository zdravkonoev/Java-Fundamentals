package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here

        for(char c='a';c <= 'z';c++)
            System.out.print(c + " ");
    }
}
